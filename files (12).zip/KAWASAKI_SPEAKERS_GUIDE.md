# KAWASAKI PROTOTYPE DELIVERY - PRESENTER GUIDE

**Presenter:** Drew Nordstrom + Manuel for technical questions  
**Natalie:** Show slides, don't talk  
**Goal:** Secure PO acceptance for phased delivery (20 + 23 units)

---

## THE POSITIONING (Your Core Message)

"We're delivering on our November 14 commitment with a phased approach. This isn't a shortage—it's quality-driven delivery that aligns perfectly with your three-phase build schedule in Japan."

---

## SLIDE-BY-SLIDE TALKING POINTS

### **SLIDE 1: Title**
- Brief intro: "Thanks for taking time. Let me walk you through our delivery plan for the 43 prototype units."

### **SLIDE 2: Program Status**
- "We're on track. Here's where we stand:"
  - **20 units** ready for immediate shipment (production quality, validated)
  - **November 14** delivery date confirmed
  - **Phase 3** design validation—exactly where we need to be

### **SLIDE 3: Delivery Plan**
**Key message:** "This phased delivery works FOR you, not AGAINST you."

- **Phase 1 (Week of Nov 10):** 20 units
  - Production-representative parts
  - LIMS validation complete
  - Aligns with your first build phase

- **Phase 2 (Week of Nov 24):** Remaining 23 units
  - Production optimization finalized
  - Fits your second and third build phases
  - Gives you time to validate first batch before full volume

### **SLIDE 4: Strategic Approach**
**Quality First (Left side):**
- "We're not compromising on quality. Here's what we're doing:"
  - LIMS-certified validation on first 20 units
  - Seal compression final tuning (this was the limiting factor)
  - All parts produced with production materials and machines—just different tooling

**Aligned with Your Builds (Right side):**
- "You asked for 43 pieces. You're getting them phased to match your build schedule."
- You have three build phases—we're giving you 20 for the first, 23 for phases 2 & 3
- This actually benefits both programs

### **SLIDE 5: Critical Path Timeline**
Walk through the three milestones:
1. **Nov 10-12:** Final assembly + LIMS validation on 20 units
2. **Nov 12-14:** Quality sign-off, packaging, delivery
3. **Nov 24-26:** Remainder ready with optimization complete

### **SLIDE 6: Next Steps**
**Three immediate asks:**
1. "Confirm you're okay accepting 20 units by Nov 14 and 23 by Nov 24—we can update the PO"
2. "Let us know your shipping instructions and inbound logistics"
3. "We'll provide preliminary test data with the first shipment"

**Close:** "We're confident in these timelines and the quality of what you're getting. Questions?"

---

## HANDLING CUSTOMER OBJECTIONS

**"Why can't you deliver all 43 by Nov 14?"**
- Response: "The limiting factor was element production and validation. We want to ensure quality before shipping. Our timeline gets you 20 production-ready units on schedule, and the remainder in two weeks as we finalize optimization."
- Don't say: "We had production issues" or "The plant broke down"
- Do say: "We're doing final tuning on seal compression to ensure these meet specification"

**"Do we need all 43, or can we start with 20?"**
- Let them answer. If yes: "Perfect, this actually works better for your build sequence. We'll ship the 23 remainder by Nov 24."
- If they say no to 20: "What's the minimum you need? We can work with that and adjust the PO."

**"Will the remainder parts be representative of production?"**
- "Yes, these will be production materials, production machines. The only difference is the tooling—soft tooling vs. hard tooling—but the parts are equivalent."

**"Why didn't you tell us about this earlier?"**
- "We've been working hard to avoid this situation. The reality is we're standing behind our quality commitment. We'd rather give you validated parts in phases than rush all 43 and risk quality issues."

---

## THINGS NOT TO SAY

❌ "We had equipment failure"  
❌ "The Mexico plant went down"  
❌ "We couldn't make them all in time"  
❌ "There's a quality issue"  
❌ "We're behind schedule"

---

## WHAT YOU'RE SELLING

✅ **Phased delivery aligned with their build schedule**  
✅ **Quality-driven approach (LIMS validated first batch)**  
✅ **Production-representative parts (not compromised)**  
✅ **Clear timeline with specific dates**  
✅ **Ownership of the solution**  

---

## IF THEY PUSH BACK HARD

**If they absolutely need 43 by Nov 14:**
- "Let's understand what's driving that. Are all 43 needed for the first build phase, or are they staged?"
- [Listen—they probably don't need all 43 immediately]
- "If you need 43 by Nov 14, that's possible but we'd need to accelerate testing. That creates quality risk. Would you prefer we ship 20 validated units now and work together to expedite the remainder if needed?"

**If they threaten to source elsewhere:**
- Stay calm. "We understand. Here's what we're committing to: 20 units Nov 14, validated and production-ready. 23 units Nov 24. If you need to explore options, we get it. But this timeline and quality level is what we're confident in."

---

## SUCCESS CRITERIA

✅ Customer accepts PO for 20 + 23 units with agreed dates  
✅ Shipping/inbound logistics confirmed  
✅ No statement that suggests quality compromise  
✅ Positive tone—customers leaves feeling confident, not concerned  

---

## POST-CALL ACTIONS

- Natalie: Send PO update within 24 hours
- Drew: Confirm shipping instructions with customer  
- Manuel: Prepare test data package for first shipment
