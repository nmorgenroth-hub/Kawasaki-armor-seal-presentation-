# KAWASAKI CALL - PRE-MEETING CHECKLIST
**Date:** November 6, 2025 | **Duration:** 30 minutes

---

## 🎯 CALL OBJECTIVE
Secure PO acceptance for phased delivery: **20 units by Nov 14 + 23 units by Nov 24**

---

## 📊 WHAT YOU'RE SHOWING
- **Slide deck:** Kawasaki_Delivery_Plan.pptx (6 slides, ~20 minutes)
- **Key narrative:** "Quality-driven phased delivery aligned with your build schedule"
- **Tone:** Confident, in-control, data-driven

---

## 🎙️ WHO TALKS WHEN
| Person | Role | Timing |
|--------|------|--------|
| **Natalie** | Display slides, own the outcome | Throughout, no extensive talking |
| **Drew** | Explain delivery plan & timeline | Slides 3-5 |
| **Manuel** | Field technical questions | As needed, Q&A |

---

## 📝 THE THREE ASKS
1. **Confirm acceptance** of 20 units by 11/14 + 23 units by 11/24 (PO update)
2. **Provide shipping instructions** for both shipments
3. **Agree to receive test data** with first batch

---

## 🔑 KEY MESSAGING (Memorize This)

### Opening
"Thanks for your time. We're on track for November 14 delivery. We've structured this as a phased approach that actually aligns better with your build schedule."

### The Story
- **Limiting factor:** Element production and final seal compression tuning
- **Solution:** Deliver 20 validated units on schedule, remainder in 2 weeks as optimization completes
- **Benefit to Kawasaki:** Matches your three-phase build schedule, gives you validation data before full volume

### Closing
"We're confident in this timeline and the quality of these parts. Are you comfortable with this delivery sequence?"

---

## ⚠️ OBJECTIONS YOU'LL LIKELY HEAR

### "Why not all 43 by Nov 14?"
**Response:** "We had production and validation work on the elements. We're not comfortable shipping all 43 without final testing. The phased approach gets you quality parts on schedule and aligns with your builds."

### "This feels like you're behind"
**Response:** "We're managing the timeline intentionally. Our commitment is delivering validated, production-representative parts. The 20 are ready now. The 23 will be ready in two weeks."

### "Can you do 30 by Nov 14?"
**Response:** "The bottleneck is LIMS validation and final tuning. To confidently deliver 30 would require rushing testing. What's driving the need for 30 vs. 20 for the first build?"

---

## ✅ BEFORE YOU CALL
- [ ] Have slide deck open and tested
- [ ] Have PO and part numbers available (P650444, P650521, etc.)
- [ ] Have test plan/LIMS list (tests 2025-015375 through 2025-015379)
- [ ] Know who's on call from Kawasaki side and their role
- [ ] Have backup info: current qty breakdowns, manufacturing facility names
- [ ] Confirm Drew & Manuel are on the call

---

## 📞 CALL FLOW (30 Minutes)
- **0-2 min:** Greeting, agenda
- **2-8 min:** Slide 2 (Status) + Slide 3 (Delivery Plan)
- **8-15 min:** Slides 4-5 (Why, Timeline)
- **15-20 min:** Slide 6 + Next Steps
- **20-30 min:** Questions, objection handling, close

---

## 💡 SUCCESS = DONE WHEN
✅ Customer confirms acceptance of 20 + 23 delivery  
✅ Shipping logistics discussed  
✅ No negative sentiment about quality  
✅ You own the call (not defensive, not desperate)

---

## 🚩 RED FLAGS TO AVOID
- ❌ Don't say "we had problems at the plant"
- ❌ Don't admit quality concerns
- ❌ Don't give soft timelines ("maybe by Nov 20")
- ❌ Don't let customer make you justify every detail
- ❌ Don't apologize excessively

---

## 📌 BOTTOM LINE FOR YOU

**You are NOT asking permission.** You are informing them of the delivery plan and confirming logistics. You have quality parts, validated timeline, and a narrative that makes sense for their program.

Say it with confidence.
