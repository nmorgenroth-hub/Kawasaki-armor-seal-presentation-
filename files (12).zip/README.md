# APD 42004 Kawasaki 5" Armor Seal Prototype - Delivery Plan Presentation

**Project:** Kawasaki OE Prototype Delivery | **Date:** November 6, 2025 | **Status:** Phase 3 - Design Validation & Testing

---

## 📋 Overview

This presentation package contains the complete delivery plan communication for the APD 42004 Kawasaki 5" Armor Seal Air Cleaner prototype program. The materials position a phased delivery approach (20 + 23 units) as a quality-driven, strategically aligned solution.

**Key Message:** "Quality-driven phased delivery aligned with your build schedule"

---

## 📦 Package Contents

### Presentation Files
- **`Kawasaki_Delivery_Plan.pptx`** - Main presentation deck (6 slides, 16:9 format)
- **`kawasaki-preview.jpg`** - Thumbnail grid of all slides
- **`slide-1.jpg` through `slide-6.jpg`** - Individual slide images (high resolution)

### Supporting Documentation
- **`KAWASAKI_PRE_CALL_CHECKLIST.md`** - Pre-call prep guide (read 10 min before meeting)
- **`KAWASAKI_SPEAKERS_GUIDE.md`** - Detailed talking points and objection handling
- **`KAWASAKI_QUICK_REFERENCE.md`** - On-call reference card with lookup tables

---

## 🎯 Presentation Structure

### **Slide 1: Title**
- Project identification: APD 42004
- Program name: 5" Armor Seal Prototype
- Context: Kawasaki Delivery Plan

### **Slide 2: Program Status** 
Three key metrics:
- **20 units** ready (production quality)
- **Nov 14** delivery commitment
- **Phase 3** (Design Validation & Testing)

### **Slide 3: Delivery Plan**
Phased delivery visualization:
- **Phase 1:** 20 units (Week of Nov 10) - Production-representative, LIMS validated
- **Phase 2:** 23 units (Week of Nov 24) - Final optimization complete
- Visual arrow connecting phases

### **Slide 4: Strategic Approach**
Two-column layout:
- **Left:** Quality First (Validation Testing, Seal Compression, Production Rep)
- **Right:** Aligned with Your Builds (matches 3-phase schedule)

### **Slide 5: Critical Path Timeline**
Three numbered milestones:
1. Nov 10-12: Final Assembly & LIMS Validation
2. Nov 12-14: Shipment Preparation
3. Nov 24-26: Remainder Shipment

### **Slide 6: Next Steps**
- Three immediate asks (PO confirmation, logistics, documentation)
- Questions slide with contact info

---

## 🎤 Presentation Approach

### **Presenters & Roles**
| Person | Role | Timing |
|--------|------|--------|
| **Natalie Erickson** | Display slides, own outcome | Throughout (minimal talking) |
| **Drew Nordstrom** | Explain delivery plan & timeline | Slides 3-5 (~7-8 minutes) |
| **Manuel Diaz** | Technical Q&A support | As needed |

### **Timing**
- **Total Duration:** 30 minutes (20 min presentation + 10 min Q&A)
- **Slide 2 (Status):** 2 min
- **Slides 3-5 (Plan & Timeline):** 8-10 min
- **Slide 6 (Close):** 2-3 min
- **Q&A:** 10 min

### **Core Message** (Memorize)
> "We're on track for November 14 delivery with a phased approach that aligns perfectly with your three-phase build schedule in Japan. Here's what you're getting and when."

---

## 📊 Key Positioning Points

✅ **What You're Selling**
- Phased delivery aligned with their build schedule
- Quality-driven approach (LIMS validated first batch)
- Production-representative parts (not compromised)
- Clear timeline with specific dates
- Ownership of solution

✅ **What You Are NOT Saying**
- ❌ "We had equipment failure"
- ❌ "The Mexico plant went down"
- ❌ "We couldn't make them all in time"
- ❌ "There's a quality issue"
- ❌ "We're behind schedule"

---

## 🎬 Likely Objections & Responses

| Objection | Response |
|-----------|----------|
| **"Why not all 43 by Nov 14?"** | "Limiting factor is element production and final seal compression tuning. 20 are ready now, 23 in 2 weeks. This aligns with your build phases." |
| **"Will first 20 be good?"** | "Yes—production materials, production machines, LIMS validated. Tooling is different but parts are equivalent to production." |
| **"Can you go faster?"** | "We could, but quality risk increases. We're comfortable with this timeline for validated parts." |
| **"What was the holdup?"** | "Element production and final design tuning. We're managing it intentionally to ensure you get quality parts." |
| **"Will remainder be same quality?"** | "Identical materials and process. First batch goes through validation; second batch completes with that data." |

---

## ✅ Success Criteria

The call is successful when:
- ✅ Customer confirms acceptance of 20 + 23 delivery plan
- ✅ Shipping logistics discussed and agreed
- ✅ No negative sentiment about quality
- ✅ Team owns the call (confident, not defensive)
- ✅ PO update scheduled within 24 hours

---

## 📝 Design Details

### **Visual Style**
- **Color Palette:** Navy blue (#1C3A47) + Teal accent (#2E8B9E)
- **Layout:** Professional, data-driven, manufacturing aesthetic
- **Typography:** Clean sans-serif, high contrast
- **Tone:** Confident, in-control, process-oriented

### **Design Elements**
- Dark navy header bars with white text
- Teal accent borders and numbers
- Clean information boxes for status metrics
- Visual flow with arrows showing phases
- Timeline with numbered circles

---

## 📋 Pre-Call Checklist

**15 Minutes Before Call:**
- [ ] Open presentation and test it runs smoothly
- [ ] Read PRE_CALL_CHECKLIST.md (2 min)
- [ ] Confirm Drew & Manuel are on the call
- [ ] Have QUICK_REFERENCE card visible
- [ ] Verify you have PO and part numbers ready
- [ ] Have test plan/LIMS info available

**During Call:**
- [ ] Display slides confidently
- [ ] Let Drew drive technical discussion
- [ ] Use Quick Reference for objection handling
- [ ] Take notes on any conditions/changes
- [ ] Confirm next steps before hanging up

**After Call:**
- [ ] Send email to team with customer decision
- [ ] Update PO if approved
- [ ] Schedule any follow-up meetings
- [ ] Notify manufacturing of any changes

---

## 📞 Contact & Escalation

**Primary Contact:** Natalie Erickson, Project Manager  
**Engineering Support:** Drew Nordstrom, Engineering Lead  
**Technical Support:** Manuel Diaz, Engineering  
**Company:** Donaldson Inc., Mobile Solutions

---

## 📂 File Locations

```
/outputs/
├── Kawasaki_Delivery_Plan.pptx          # Main presentation (editable)
├── Kawasaki_Delivery_Plan.pdf           # PDF version
├── kawasaki-preview.jpg                 # Thumbnail grid (all slides)
├── slide-1.jpg through slide-6.jpg      # Individual slides (high res)
├── KAWASAKI_PRE_CALL_CHECKLIST.md       # Pre-call prep
├── KAWASAKI_SPEAKERS_GUIDE.md           # Talking points
├── KAWASAKI_QUICK_REFERENCE.md          # On-call reference
└── README.md                            # This file
```

---

## 🔄 Using These Materials

### **Option 1: In-Person Meeting**
1. Download `Kawasaki_Delivery_Plan.pptx`
2. Review `KAWASAKI_PRE_CALL_CHECKLIST.md` 10 min before
3. Have `KAWASAKI_QUICK_REFERENCE.md` open during call
4. Present from the PPTX file directly

### **Option 2: Virtual Meeting / Zoom**
1. Share `Kawasaki_Delivery_Plan.pptx` screen
2. Have QUICK_REFERENCE visible on second monitor
3. Use speaker notes from SPEAKERS_GUIDE for context
4. Screen share individual slides if needed

### **Option 3: GitHub / Async Review**
1. Share slide thumbnails (`slide-1.jpg` through `slide-6.jpg`)
2. Include `README.md` with context
3. Provide `KAWASAKI_SPEAKERS_GUIDE.md` for detailed explanation
4. Link to full PPTX for direct download

### **Option 4: Email / Proposal**
1. Attach `Kawasaki_Delivery_Plan.pdf` 
2. Include key messaging from QUICK_REFERENCE
3. Add supporting documentation links
4. Request meeting to review live presentation

---

## 💡 Tips for Success

1. **Show confidence.** This is a deliberate, quality-driven approach—not firefighting.
2. **Data-driven.** Reference specific dates, unit counts, and validation steps.
3. **Customer-focused.** Frame everything around benefits to Kawasaki's program.
4. **Let slides do the talking.** You're there to answer questions, not read slides.
5. **Own the outcome.** No apologies, no defensiveness. Solution-oriented.

---

## 📌 Version History

| Version | Date | Status | Notes |
|---------|------|--------|-------|
| 1.0 | Nov 6, 2025 | Final | Initial release for 11/6 call |

---

## 📖 Additional Resources

- See `KAWASAKI_PRE_CALL_CHECKLIST.md` for detailed objection scripts
- See `KAWASAKI_SPEAKERS_GUIDE.md` for full talking points by slide
- See `KAWASAKI_QUICK_REFERENCE.md` for on-call lookup tables
- See `Kawasaki_Delivery_Plan.pptx` for editable source file

---

**Ready to present. Let's go own this call.** ✅
