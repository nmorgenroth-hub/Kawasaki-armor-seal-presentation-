# KAWASAKI DELIVERY PLAN - QUICK REFERENCE CARD

## THE NUMBERS
| Metric | Value |
|--------|-------|
| Phase 1 Units | 20 |
| Phase 2 Units | 23 |
| **Total** | **43** ✓ |
| Phase 1 Delivery | Week of Nov 10 (Target: Nov 14) |
| Phase 2 Delivery | Week of Nov 24 |
| Current Status | Production quality, LIMS validated pending |
| Project Phase | 3 (Design Validation & Testing) |

---

## YOUR POSITION
✓ You have 20 units production-ready  
✓ 23 more units in final stages  
✓ Timeline is firm - Nov 14 and Nov 24  
✓ Quality is locked - LIMS validated  
✓ This matches their 3-build schedule  

---

## IF THEY ASK... SAY THIS

| Question | Answer |
|----------|--------|
| "Why not all 43?" | "Limiting factor is final seal compression tuning and LIMS validation. 20 are ready now, 23 in 2 weeks. This aligns with your build phases." |
| "Will first 20 be good?" | "Yes—production materials, production machines, LIMS validated. Tooling is different but parts are equivalent to production." |
| "Can you go faster?" | "We could, but quality risk increases. We're comfortable with this timeline for validated parts." |
| "What was the holdup?" | "Element production and final design tuning. We're managing it intentionally to ensure you get quality parts." |
| "Will remainder be same quality?" | "Yes, identical materials and process. First batch goes through validation; second batch completes with that data." |

---

## CRITICAL COMMITMENTS (Don't back off)
🔴 **Final ship date: Nov 14 for 20 units**  
🔴 **Final ship date: Nov 24 for 23 units**  
🔴 **Quality standard: Production-representative, LIMS validated**  

---

## THINGS YOU CAN BE FLEXIBLE ON
🟢 Breakdown within phases (e.g., 15+5 vs. 20)  
🟢 Exact drop dates (Nov 10-14 range is flexible)  
🟢 Shipping methods/logistics  
🟢 Test data package timing (with shipment vs. shortly after)  

---

## CLOSE LANGUAGE
**After slides:**
"So here's what we're proposing: 20 validated units ship by November 14, 23 more by November 24. This timeline is firm, quality is locked. Are you comfortable with this delivery plan?"

**If they say yes:**
"Great. What we need from you: shipping instructions and confirmation we can update the PO to reflect these phases."

**If they push:**
"What's most important to you—the Nov 14 date, the unit count, or the quality standard? Let's figure out what we can solve together."

---

## PEOPLE & PART NUMBERS (In case you need them)
**Part Numbers:**  
- P650444 (Outer End Cap WO Liner)  
- P650521 (Safety Parts)  
- P650430 (Primary Filter)  
- P650608 (Brass Outlet)  

**Kawasaki Contact (if needed):** [To be filled by team]  
**Donaldson Team on Call:** Natalie (PM), Drew (Engineering), Manuel (Support)  

---

## IN CASE OF CRISIS
If customer demands 43 by Nov 14:
1. Don't panic—stay on the line
2. Say: "Let me check with our production team on feasibility"
3. **DON'T PROMISE ANYTHING**
4. Get back to them within 4 hours with answer
5. If you can't do it, explain why + what you CAN do

If customer wants to cancel:
1. Don't react defensively
2. Ask: "What's driving this decision?"
3. Listen
4. Offer: "Let's see if there's a way to work this out. What does success look like?"

---

## AFTER THE CALL
✅ Send Natalie email with:
- Customer decision (yes/no/negotiate)
- Any conditions or changes
- Next meeting date (if needed)
- Action items with owners

✅ Update PO immediately if approved

✅ Send Drew manufacturing update if numbers change
